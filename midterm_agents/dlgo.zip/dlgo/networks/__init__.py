from dlgo.networks import fullyconnected
from dlgo.networks import large
from dlgo.networks import leaky
from dlgo.networks import medium
from dlgo.networks import small
