from dlgo.encoders.base import *
#from dlgo.encoders.alphago import *
from dlgo.encoders.betago import *
from dlgo.encoders.oneplane import *
from dlgo.encoders.sevenplane import *
from dlgo.encoders.simple import *