from .alphabeta import *
from .depthprune import *
from .minimax import *
